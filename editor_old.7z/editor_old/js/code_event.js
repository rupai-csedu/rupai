Blockly.Python['event_voice'] = function(block) {
  var dropdown_voice_command = block.getFieldValue('voice_command');
  var statements_voice_statements = Blockly.Python.statementToCode(block, 'voice_statements');
  // TODO: Assemble Python into code variable.
  var code = '...\n';
  return code;
};


Blockly.Python['event_light_left'] = function(block) {
  var dropdown_light_left_dropdown = block.getFieldValue('light_left_dropdown');
  var statements_light_left_statements = Blockly.Python.statementToCode(block, 'light_left_statements');
  // TODO: Assemble Python into code variable.
  var code = '...\n';
  return code;
};


Blockly.Python['event_light_right'] = function(block) {
  var dropdown_light_right_dropdown = block.getFieldValue('light_right_dropdown');
  var statements_light_right_statements = Blockly.Python.statementToCode(block, 'light_right_statements');
  // TODO: Assemble Python into code variable.
  var code = '...\n';
  return code;
};

Blockly.Python['event_light_centre'] = function(block) {
  var dropdown_light_centre_dropdown = block.getFieldValue('light_centre_dropdown');
  var statements_light_centre_statements = Blockly.Python.statementToCode(block, 'light_centre_statements');
  // TODO: Assemble Python into code variable.
  var code = '...\n';
  return code;
};
